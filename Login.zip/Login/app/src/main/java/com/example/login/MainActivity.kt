package com.example.login

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView


class MainActivity : AppCompatActivity() {
    val usuValid = "admin"
    val contrValida = "1234"
    var contadorIntents = 0
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        if (savedInstanceState !=null) {
            contadorIntents =savedInstanceState.getInt("intents")

        }
        val editTextUsername=findViewById<TextView>(R.id.editTextUsername)
        editTextUsername.setHint("Username")
        val editTextPassword =findViewById<TextView>(R.id.editTextTextPassword)
        editTextPassword.setHint("Password")
        val btlogin=findViewById<Button>(R.id.btLogin)
        val textViewContadorIntents= findViewById<TextView>(R.id.textViewContadorIntents)
        if (savedInstanceState !=null) {
            contadorIntents =savedInstanceState.getInt("intents")
        }
        textViewContadorIntents.setText(contadorIntents.toString())


        btlogin.setOnClickListener {
            var nameIntent = editTextUsername.getText().toString()
            var passwIntent = editTextPassword.getText().toString()
            if (nameIntent.equals(usuValid) && passwIntent.equals(contrValida) && (contadorIntents <= 3)) {
                val intent = Intent(baseContext, Welcome::class.java)
                contadorIntents = 0
                intent.putExtra("nameIntent", nameIntent)
                textViewContadorIntents.setText(contadorIntents.toString())
                startActivity(intent)

            }else if (!nameIntent.equals("")&& !passwIntent.equals("") && (contadorIntents < 3)){
                contadorIntents ++
                textViewContadorIntents.setText(contadorIntents.toString())
            }
        }
    }
    override fun onSaveInstanceState(estat: Bundle) {
        super.onSaveInstanceState(estat)
        estat.putInt("intents", contadorIntents)
    }
    override fun onRestoreInstanceState(estat: Bundle) {
        super.onRestoreInstanceState(estat)
        contadorIntents =estat.getInt("intents")
    }

}